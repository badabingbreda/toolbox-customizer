// error alert for toolbox-customizer; translated variables added using script-localization
( function() {
	alert( tbCustomizer.whoops + '\n\n' + tbCustomizer.compiled_css + '\n\n' + tbCustomizer.addconstant );
})();